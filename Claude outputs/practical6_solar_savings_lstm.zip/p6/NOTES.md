# Practical 6 — Forecasting solar radiation with an LSTM to estimate the savings and payback of rooftop panels

Built 2 Nov 2026. Folder `docs/practicals/solar_savings_lstm/`.

## Files
- `index.md` — the practical page. The Colab badge still points to `COLAB_LINK_PENDING`: upload the STUDENT notebook to Drive and paste the `drive/<id>` link.
- `build_p6.py` — builds `MEEN41490_P6_Solar_Savings_STUDENT.ipynb` (27 cells) and, with `--teacher`, the TEACHER notebook (33 cells, worked attempts in Part 3).
- `MEEN41490_P6_Solar_Savings_TEACHER_executed.ipynb` — the teacher notebook run end to end on a 2-core CPU (158 s), house 1.
- `assets/` — the three Part 0 figures (made from the real data with `figs_part0.py` in the session) and `assets/data/` with the five data files that the setup cell downloads from `DATA_URL`.

## Data
- `dingle_weather_2010_2021.csv` — Open-Meteo archive API, ERA5, lat 52.141 lon -10.269 (Dingle), hourly UTC, 12 variables, tilt 30°, azimuth 0 (south), wind in m/s. CC BY 4.0, attribution "Open-Meteo / Copernicus Climate Change Service". 105,192 rows, 5.9 MB. The notebook uses 2010 to 2019.
- `house1.csv` to `house4.csv` — Avgoloupis et al. (2026), Scientific Data 13:834, Figshare 10.6084/m9.figshare.30294478, CC BY 4.0. Reduced to `timestamp, solar_kWh, import_kWh, export_kWh, elec_price` (the notebook drops `elec_price`, a tariff scenario of the study). 30-min, Jan 2019 to Feb 2022. Import and export are missing for about 70 days in Jan–Apr 2019 in every house. June–July 2021 production is zero in houses 2–4 (meter change), so the comparison year is **2019**, the cleanest year.
- Years: train 2010–2017, validation 2018, estimate and reality 2019.

## Results observed (seed 0, 2-core CPU)
- Baselines on 2018: same as this hour 36.3 W/m², same hour yesterday 51.6 W/m².
- First model (radiation only, 16 units, 5 epochs, lr 0.001): 22.9 W/m², 1,233 parameters, 7–13 s.
- 10 epochs at lr 0.003: about 20. + cloud_cover: 17.5–20.7 depending on the seed. + direct, diffuse, temperature, humidity, wind: 16.8–18.6. 32 units × 2 layers: 17.3 in 47 s. 8 units: 20.0 (457 parameters). Hour of day and day of year add little. Target of the challenge: 20 W/m², under 60 s.
- Tilt factor 1.16. Performance factor 0.80. Estimate 2019 for 2.1 kW: about 1,960–1,990 kWh.
- Reality 2019 (complete months): house 1 +3 % gap (1,863 real), house 2 +18 % (Dec outage, 3 kWh), house 3 +43 % (10 complete months, low output all year), house 4 +11 %.
- Money (0.35 buy, 0.195 export, 2,100 €/kW, grant 1,800): net cost 2,610 €, projected saving 581–665 €/yr, payback 3.9–4.5 yr; real payback house 1 4.9 yr.

## Sources for the money figures (checked 2 Nov 2026)
- SEAI Solar Electricity Grant page: €900/kWp up to 2 kWp (€1,800 for 2 kWp), cap €2,400 with a battery, typical cost €1,700–2,500 per kWp. A Selectra page shows a lower 2026 table (cap €1,800); SEAI is the primary source.
- Clean Export Guarantee (Selectra table, updated 1 Nov 2026): SSE Airtricity and Electric Ireland 19.5 c/kWh, most others 18.5 c/kWh.
- Buying price 0.35 €/kWh is a round typical unit rate (Selectra uses 0.42 in one calculation).

## To do
- Upload STUDENT to Drive, paste the Colab link in `index.md`, commit and push (the setup cell needs `assets/data/` live on github.io).
- Optional: re-execute the teacher notebook in Colab to refresh `_executed`.
